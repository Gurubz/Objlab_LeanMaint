﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ug",{title:"ئېلېمېنت ئۇچۇرى",dialogName:"سۆزلەشكۈ كۆزنەك ئاتى",tabName:"Tab ئاتى",elementId:"ئېلېمېنت كىملىكى",elementType:"ئېلېمېنت تىپى"});